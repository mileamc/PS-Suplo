# Briefing — Site de apresentação do case Suplos

Este documento reúne tudo que é necessário para construir o site. Não invente informação que não esteja aqui — se faltar algo, pergunte antes de prosseguir.

---

## Objetivo

Um site único, em ordem cronológica, apresentando todo o processo do case da Suplos (Product Designer): do diagnóstico do problema até o protótipo funcional já construído nesta mesma sessão do Claude Code. É um material bônus, complementar à apresentação ao vivo.

---

## Estrutura do site (nesta ordem)

1. Introdução (com agradecimento)
2. Overview do projeto
3. Etapas do processo
4. Fluxogramas originais da Suplos, comentados
5. Prints das telas atuais, anotados
6. Fluxo de estados (V1) — versão só de estados
7. Fluxo de estados enriquecido com UI + tabela de atores + tabela de notificações
8. MVP, V.1, V.2 e V.3
9. Protótipo interativo (web e mobile)
10. Encerramento

---

## Estilo visual — regras importantes

- **Paleta:** apenas tons de azul e neutros (cinza/branco/preto). Não usar verde, coral, âmbar ou outras cores — mesmo que apareçam nos arquivos SVG anexos (esses SVGs foram feitos com paleta multicolor; ao reproduzir o conteúdo deles no site, adapte para tons de azul e neutros, mantendo a mesma estrutura e legibilidade).
- **Protótipo (seção 9): NÃO alterar nada do design.** O protótipo já foi construído nesta sessão do Claude Code, com sua própria identidade visual (reaproveitando a marca da Suplos). Ele deve ser incorporado exatamente como está, sem recolorir, sem redesenhar.
- **Separação visual clara** entre o protótipo (seção 9) e o resto do site: o protótipo deve estar visualmente destacado (por exemplo, dentro de um frame/mockup de navegador para a versão web e um frame de celular para a versão mobile), para ficar óbvio que ali é uma peça funcional à parte, com seu próprio estilo, diferente do restante do site.
- **Placeholders de imagem:** onde for necessário uma foto (ex: se decidir incluir uma foto minha na introdução, ou qualquer imagem que não esteja anexada), usar um placeholder claramente identificado como tal — não gerar nem inventar imagem nenhuma.
- Site deve ser responsivo (funciona bem tanto no desktop de quem for avaliar quanto em mobile).

---

## Conteúdo de cada seção

### 1. Introdução

> Oi! Antes de qualquer coisa, obrigada pela oportunidade de chegar até essa etapa — sei que o volume de candidaturas foi grande, e fico feliz de estar aqui.
>
> Esse case foi desenhado com lacunas de propósito, e decidi tratar isso como parte do desafio, não como um obstáculo. Em vez de desenhar telas direto, segui um processo: primeiro entendi a marca e o produto, depois analisei as telas que já existem, destrinchei as dores e os objetivos por trás do pedido, mapeei os pontos de fricção do fluxo atual, modelei os estados que resolvem esses pontos, e só então parti para a produção das telas.
>
> Esse site apresenta esse processo do início ao fim, na ordem em que ele aconteceu — incluindo os pontos em que discordei do material que vocês me deram, e por quê.

*(Texto em primeira pessoa, provisório — a pessoa candidata vai revisar o tom antes da entrega final. Não alterar o conteúdo/sentido, só formatar.)*

### 2. Overview do projeto

> O problema, resumido: hoje, transferir material entre obras é uma ação instantânea — o saldo sai da origem e entra no destino no mesmo clique, sem aprovação, sem reserva, sem confirmação de que o material chegou. Na prática, o caminhão leva de 3 a 7 dias, e a quantidade que sai pode não ser igual à que chega. O sistema atual não modela esse intervalo nem essa divergência.
>
> Minha abordagem: em vez de ir direto para o desenho de telas, tratei isso primeiro como um problema de **modelagem de estados** — o que a transferência "é" em cada momento do tempo — e só depois decidi como isso aparece na interface. Acredito que essa ordem produz uma solução mais sólida, porque separa "o que o sistema faz" de "como isso é mostrado", e evita que decisões de UI escondam buracos de lógica.

### 3. Etapas do processo

Apresentar como linha do tempo ou lista numerada visual:

1. **Entender a marca e o produto** — a Suplos como plataforma de gestão de suprimentos para construção civil, e onde a transferência se encaixa nesse ecossistema.
2. **Analisar as telas existentes** — o que já funciona, o que quebra, e o que pode ser reaproveitado como padrão (a comparação "pedido x recebido" do modal de pedidos de compra, por exemplo, já existia — só não tinha sido aplicada aqui).
3. **Destrinchar dores e objetivos** — separar o que os usuários reais pediram (via time de CS) do que é só sintoma superficial.
4. **Analisar os três fluxogramas originais** — e questionar, como pedido, os pontos que não faziam sentido.
5. **Mapear pontos de fricção** — cruzando os prints das telas atuais com as dores relatadas.
6. **Modelar os estados** — transformar a transferência de uma ação única em um processo com etapas, decisões e responsáveis.
7. **Produzir** — desenhar o recorte de alta-fidelidade em cima do modelo de estados já validado.

### 4. Fluxogramas originais comentados

**Texto de introdução da seção:**

> Os três fluxogramas que vocês forneceram (Criação, Aprovação, Recebimento) vieram com uma instrução explícita: questionar o que não fizesse sentido. Encontrei três pontos que valem discussão — um deles, inclusive, uma contradição real dentro do próprio material.
>
> **Fluxo de Criação:** confirmei a leitura de que "Requisição de Material" é um pedido interno da própria obra de origem, não algo vindo do destino — a transferência é sempre iniciada por quem tem sobra. Mas fiquei com uma dúvida real: por que toda transferência aparece na aba `/requisitions`, mesmo quando nasce direto de uma Saída de Estoque, sem ter passado por uma requisição? Minha proposta é que isso só deveria acontecer quando a transferência de fato se originou de uma requisição.
>
> **Fluxo de Aprovação:** o rascunho duplica toda a árvore de decisão duas vezes — uma para quando o parâmetro de aprovador está ligado, outra idêntica para quando está desligado. Isso é redundante e propenso a divergir com o tempo. Simplifiquei para que o parâmetro apenas decida se o estado "Aguardando aprovação" existe no fluxo ou é pulado, sem duplicar a lógica inteira.
>
> **Fluxo de Recebimento — a contradição real:** o modal de confirmação de entrega mostra a avaliação de entrega (FVM) como **opcional**. Mas se ela pode ser pulada, a divergência entre o que saiu e o que chegou — o problema central citado no case — nunca é capturada. Isso contradiz a própria necessidade de auditoria que vocês descreveram. Minha proposta: a conferência de *quantidade* deveria ser obrigatória; só os critérios de *qualidade* da avaliação é que fazem sentido como configuráveis por cliente.

**Asset:** `fluxogramas_originais_comentados.svg` (ou o `.png` equivalente) — recriar o conteúdo desse arquivo no site, adaptando as cores para tons de azul/neutro (no arquivo original, vermelho = discordância e azul = premissa confirmada; no site, usar duas variações de azul — um mais escuro/saturado para discordância, um mais claro para premissa — para manter a distinção sem sair da paleta).

### 5. Prints das telas atuais, anotados

**Texto de introdução da seção:**

> Antes de desenhar qualquer coisa nova, fiz um diagnóstico visual em cima do produto como ele existe hoje. Cada marcação abaixo liga um ponto específico da interface a uma dor real (dos prints e do vídeo de apresentação) e, quando aplicável, ao estado do fluxo novo que resolve aquilo.
>
> O achado que mais gostei: o modal de "Detalhes do Pedido" (para pedidos de compra) já tem, hoje, uma comparação lado a lado entre quantidade pedida e quantidade recebida. Isso não é um recurso que estou inventando — é um padrão que a Suplos já usa em outro lugar do produto. Meu trabalho foi reconhecer esse padrão e propor que ele seja reaproveitado para transferências entre obras, em vez de criar algo do zero.

**Assets:** `print1_estoque_materiais.svg` até `print5_detalhes_pedido.svg` (ou o arquivo combinado `analise_anotada_prints_completa.svg`). Adaptar cores dos callouts para tons de azul/neutro.

### 6. Fluxo de estados (V1)

**Texto de introdução da seção:**

> Esse é o resultado da etapa de modelagem: a transferência deixa de ser uma ação única e passa a ter um ciclo de vida — reservada, aguardando aprovação, em trânsito, avaliada na entrega, e recebida (com ou sem divergência), com os devidos caminhos de reprovação e cancelamento.
>
> Uma decisão que assumo e defendo: quando há divergência e o remetente decide reenviar o material faltante, o fluxo volta para o estado **Reservado**, não direto para "Em trânsito" — e passa pela aprovação de novo, do zero. Isso custa mais fricção para quem já errou uma vez, mas evita reabrir exatamente a brecha que esse case pede para fechar: material saindo do estoque sem nenhuma validação.

**Asset:** `fluxo_transferencia_v1_linha_unica.svg`. Adaptar cores para azul/neutro.

### 7. Fluxo enriquecido + tabela de atores + tabela de notificações

**Texto de introdução da seção:**

> Aqui eu pego o mesmo fluxo de estados e acrescento a camada que estava faltando: em qual modal, mensagem ou aba cada transição aparece — no mesmo nível de detalhe que os fluxogramas originais de vocês tinham.
>
> Ao lado, a tabela de atores responde a uma exigência específica do material (*"cada estado permite ações diferentes para pessoas diferentes"*): quem decide o quê, em cada estado. Simplifiquei para dois papéis — Origem e Destino — porque, como o próprio glossário de vocês confirma, o papel de aprovador é configurável por cliente; não faz sentido eu fixar um cargo específico.
>
> Um detalhe que só descobri ouvindo o vídeo de apresentação com atenção (não estava em nenhum slide): a confirmação de recebimento é o único evento do fluxo inteiro que notifica as três partes ao mesmo tempo — origem, aprovador e destino. Isso está registrado na tabela de notificações, separada da tabela de decisão, porque nem sempre quem decide é quem precisa saber.

**Assets:** `fluxo_v1_enriquecido.svg`, `tabela_atores_por_estado.svg`, `tabela_notificacoes.svg`. Adaptar cores para azul/neutro, mantendo a distinção semântica (ex: origem vs destino continuam precisando ser visualmente diferentes, mas em dois tons de azul em vez de verde/azul).

### 8. MVP, V.1, V.2 e V.3

**Texto de introdução da seção:**

> Eu não escolhi o que construir primeiro por preferência pessoal — ancorei a priorização nos quatro pedidos explícitos que o time de CS trouxe (aprovação obrigatória, reserva, confirmação de recebimento, visibilidade por obra). Os quatro têm o mesmo peso no material, então os quatro entram no MVP.

**MVP:** reserva, aprovação condicional, trânsito, avaliação de entrega com registro de divergência, cancelamento, e o painel de visibilidade por obra ("A Enviar" / "A Receber"). Fica de fora, por decisão consciente: qualquer forma de correção automática da divergência — ela é registrada, mas resolvida manualmente por enquanto.

**V.1:** o loop de reenvio após divergência — o remetente pode corrigir e reenviar, passando pela aprovação de novo. Trade-off assumido: mais fricção para quem já errou, decisão deliberada para não reabrir a brecha do case.

**V.2:** uma ideia própria, que não vem de nenhum pedido do CS — sugestão automática de destino, cruzando o momento de reserva com o card "Estoque Baixo" que já existe no produto. Deixo isso explícito como proposta minha, não como resposta a um requisito.

**V.3:** aqui o próprio case pede melhoria além do fluxo atual, não só fechamento de lacunas. Proponho: confirmação de carregamento pelo transportador (segundo ponto de conferência, na saída); alerta de atraso no trânsito, reaproveitando o padrão que já existe na tela de Entregas; indicador de confiabilidade por obra/rota; e modo offline no mobile para confirmação de recebimento — porque quem confirma está no canteiro, no sol, de luva, com conexão ruim.

> Também decidi, conscientemente, **não** incluir em nenhuma versão: cancelamento ou devolução depois que o material já foi confirmado como recebido (isso quebraria a premissa de que o fluxo tem um fim, e nada no material indica que essa seja uma dor real), e qualquer forma de aprovação totalmente automática (é uma decisão de controle financeiro da construtora, fora do escopo que me cabe decidir neste case).

**Asset:** `mvp_v1_v2_v3.svg` (já está em tons de azul e neutro — pode ser incorporado praticamente como está, sem necessidade de readaptação de cor).

### 9. Protótipo interativo

**Texto de introdução da seção:**

> Depois de validar o modelo de estados, o próximo passo foi trazer isso para telas de verdade — reaproveitando a identidade visual da Suplos e os padrões que já existem no produto (como a comparação "pedido x recebido"), em vez de propor um visual do zero.
>
> Abaixo está o protótipo funcional, navegável tanto na versão web (fluxo de criação e aprovação, pensado para quem trabalha no escritório) quanto na versão mobile (fluxo de recebimento, pensado para quem está no canteiro). Ele cobre o recorte do MVP descrito acima, incluindo o estado de recebimento com divergência — o caminho "não-feliz" que o case pede que apareça no recorte de alta-fidelidade.

**Importante:** incorporar o protótipo já construído nesta sessão do Claude Code, **sem alterar seu design**. Usar um frame de navegador para a versão web e um frame de celular para a versão mobile, deixando claro que ali é uma peça interativa separada do restante do site (que segue a paleta azul/neutra deste briefing).

### 10. Encerramento

> Esse foi meu processo do início ao fim: entender antes de desenhar, questionar o que não fazia sentido, e tomar decisões que eu conseguisse defender — inclusive as que envolveram dizer não a alguma coisa. Obrigada por chegarem até aqui comigo, e fico à disposição para detalhar qualquer ponto na apresentação.

---

## Lista de assets SVG/PNG disponíveis (na pasta de outputs)

- `fluxogramas_originais_comentados.svg` / `.png`
- `print1_estoque_materiais.svg` até `print5_detalhes_pedido.svg`
- `analise_anotada_prints_completa.svg` (os 5 prints combinados em um arquivo)
- `fluxo_transferencia_v1_linha_unica.svg`
- `fluxo_v1_enriquecido.svg` / `.png`
- `tabela_atores_por_estado.svg`
- `tabela_notificacoes.svg` / `.png`
- `mvp_v1_v2_v3.svg` / `.png`

## Se faltar informação

Não inventar conteúdo, texto ou dado que não esteja neste documento ou nos arquivos anexos. Se for necessário algo que não está aqui (por exemplo, foto de perfil, link de contato, nome completo para créditos), perguntar antes de prosseguir.
